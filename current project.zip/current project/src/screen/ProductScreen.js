import React from 'react';
import{Link} from 'react-router-dom';
import{Row,Col,image,ListGroup,Card,Button} from 'react-bootstrap';
import products from '..products/'
import Rating from '../component/Rating'

const ProductScreen = () => {
    const product=products.find(p=>p._id)
    return (
      
    )

}

export default ProductScreen
