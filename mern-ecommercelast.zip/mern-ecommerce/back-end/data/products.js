const products = [
    {
      
      name: 'Ragular fit casual shirt ',
      image: '/images/shirt.png',
      description:
        ' White Oxford regular fit shirt, has a button-down collar, long sleeves, full button placket, a patch pocket,a curved ',
      brand: 'Gulati',
      category: 'mens-shirt',
      price: 10.99,
      countInStock: 10,
      rating: 4.5,
      numReviews: 12,
    },
    {
      
      name: 'iPhone 11 Pro 256GB Memory',
      image: '/images/phone.png',
      description:
        'Introducing the iPhone 11 Pro. A transformative triple-camera system that adds tons of capability without complexity. An unprecedented leap in battery life',
      brand: 'Apple',
      category: 'Electronics',
      price: 599.99,
      countInStock: 7,
      rating: 4.0,
      numReviews: 8,
    },
    {
      
      name: 'Nikon EOS 80D DSLR Camera',
      image: '/images/camera.png',
      description:
        'Characterized by versatile imaging specs, the Nikon EOS 80D further clarifies itself using a pair of robust focusing systems and an intuitive design',
      brand: 'Nikon',
      category: 'Electronics',
      price: 929.99,
      countInStock: 5,
      rating: 3,
      numReviews: 12,
    },
    {
    
      name: 'Sony Playstation 4 Pro Black Version',
      image: '/images/playstation.png',
      description:
        'The ultimate home entertainment center starts with PlayStation. Whether you are into gaming, HD movies, television, music',
      brand: 'Sony',
      category: 'Electronics',
      price: 399.99,
      countInStock: 11,
      rating: 5,
      numReviews: 12,
    },
    {
    
      name: 'Logitech G-Series Gaming Mouse and keybords',
      image: '/images/mouse.png',
      description:
        'Get a better handle on your games with this Logitech LIGHTSYNC gaming mouse and keybord. The six programmable buttons allow customization for a smooth playing experience',
      brand: 'Logitech',
      category: 'Electronics',
      price: 49.99,
      countInStock: 7,
      rating: 3.5,
      numReviews: 10,
    },
    {

      name: 'Gulati speakers 3rd Generation',
      image: '/images/speakers.png',
      description:
        'Meet Gulati sound system - Our most popular smart speaker with a fabric design. It is our most compact smart speaker that fits perfectly into small space',
      brand: 'Gulati',
      category: 'Electronics',
      price: 29.99,
      countInStock: 0,
      rating: 4,
      numReviews: 12,
    },
  ]
  
  export default products;
